<template>


  <div>
      <Comentarios/>
  </div>
</template>

<script>
import Comentarios from '../Blog/Components/Comentario.vue'
export default {
    name: 'Blog',
    components: {
        Comentarios,
    }

    
}
</script>